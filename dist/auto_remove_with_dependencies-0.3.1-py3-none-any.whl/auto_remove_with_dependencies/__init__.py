# auto_remove_with_dependencies/__init__.py
__version__ = "0.3.1"
