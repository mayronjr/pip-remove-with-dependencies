# auto_remove_with_dependencies/__init__.py
__version__ = "0.1.3"
