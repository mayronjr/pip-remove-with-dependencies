BLOCKED_PACKAGES = {'pip', 'setuptools', 'autoremove'}
