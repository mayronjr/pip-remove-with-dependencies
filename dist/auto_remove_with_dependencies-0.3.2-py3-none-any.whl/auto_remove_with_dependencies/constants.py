BLOCKED_PACKAGES = {'pip', 'setuptools', 'auto_remove_with_dependencies'}
